---
name: Obsidian Street Relatable Apparel
colors:
  surface: '#131317'
  surface-dim: '#131317'
  surface-bright: '#39393d'
  surface-container-lowest: '#0e0e12'
  surface-container-low: '#1b1b1f'
  surface-container: '#1f1f23'
  surface-container-high: '#2a292e'
  surface-container-highest: '#353439'
  on-surface: '#e4e1e7'
  on-surface-variant: '#d6c4ac'
  inverse-surface: '#e4e1e7'
  inverse-on-surface: '#303034'
  outline: '#9e8e78'
  outline-variant: '#514532'
  surface-tint: '#ffba38'
  primary: '#ffd79b'
  on-primary: '#432c00'
  primary-container: '#ffb300'
  on-primary-container: '#6b4900'
  inverse-primary: '#7e5700'
  secondary: '#ffb5a0'
  on-secondary: '#5f1500'
  secondary-container: '#d73b00'
  on-secondary-container: '#fffbff'
  tertiary: '#69f6b9'
  on-tertiary: '#003824'
  tertiary-container: '#48d99e'
  on-tertiary-container: '#005b3d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdeac'
  primary-fixed-dim: '#ffba38'
  on-primary-fixed: '#281900'
  on-primary-fixed-variant: '#604100'
  secondary-fixed: '#ffdbd1'
  secondary-fixed-dim: '#ffb5a0'
  on-secondary-fixed: '#3b0900'
  on-secondary-fixed-variant: '#862200'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#131317'
  on-background: '#e4e1e7'
  surface-variant: '#353439'
typography:
  display-hero:
    fontFamily: Newsreader
    fontSize: 68px
    fontWeight: '400'
    lineHeight: 74px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Newsreader
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 46px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 42px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  price-hero:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 26px
    letterSpacing: -0.01em
  label-badge:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-caption:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The brand personality merges intellectual irony, chaotic internet lore, and heavyweight urban streetwear culture. Built specifically for contemporary young Indian creators, software engineers, postgraduate researchers, and corporate survivors, the brand flips everyday professional angst and academic existentialism into premium wearable badges of honor.

The aesthetic philosophy is **High-Contrast Dark Brutalism infused with Editorial Streetwear**. It blends deep, light-absorbing obsidian foundations with laser-sharp electric accents (amber gold, signal orange, and cyber green). Editorial high-contrast serif typography grounds the aesthetic with academic prestige and intellectual gravitas, juxtaposed aggressively against stark, utilitarian neo-grotesque sans-serif and spontaneous, hand-scrawled meme annotations. 

The emotional response is instant recognition, cynical humor, and immediate belonging—instilling the tactile confidence of 240 GSM heavy-knit street garments paired with lightning-fast, zero-friction D2C purchase loops tailored for India's digital-first commerce ecosystem.

## Colors

The palette is engineered around an uncompromising deep-black environment to maximize graphical punch, apparel mock vibrancy, and hyper-legible pricing cues:

- **Surface System (Neutral Base):**
  - Canvas Deep: `#0D0D11` (Obsidian canvas with sub-perceptual blue-violet depth).
  - Surface Raised / Card Base: `#16161D` (Structural elevated layers and product tiles).
  - Surface Border / Hairline: `#262633` (Precision razor boundaries).
  - High Surface / Hover: `#22222E` (Interactive surface feedback).

- **Chromatic Accents:**
  - **Primary (`#FFB300` - Amber Gold):** Carries commercial focus, review ratings, primary CTA micro-highlights, and high-prestige editorial drop capitals.
  - **Secondary (`#FF5722` - Electric Flame Orange):** Drives urgent purchase buttons, drop countdowns, limited run warnings, and meme highlight scribbles.
  - **Tertiary (`#10B981` - Cyber Mint):** Designates verified stock, UPI instant-payment badges, free delivery confirmations, and positive trust signals.

- **Typography & Content Contrast:**
  - Headings / Display: `#F8FAFC` (Crisp off-white).
  - Body Content: `#CBD5E1` (Muted functional slate).
  - Secondary / Editorial Footnotes: `#64748B` (Subtle low-contrast metadata).

## Typography

The type system constructs tension between academic intellectualism and brutalist digital culture:

- **Editorial Headlines (`Newsreader`):** Used with italic flourishes for oversized hero slogans ("PhD Life. Unfiltered", "Burnout Edition"), lending a mock-prestigious, literary framing to existential meme graphics.
- **Product & Technical Data (`Space Grotesk`):** Manages all numbers, rupee prices (`₹999`), badge text, specifications (240 GSM, 100% Bio-Wash), and technical SKU navigation.
- **Body & Interface (`Plus Jakarta Sans`):** Provides pristine legibility across product blurbs, checkout inputs, and customer reviews.
- **Hand-drawn Annotations:** Micro-copy, arrows, and sarcastic doodles ("Same Researchers Different Days...", smiley face outlines) utilize tilted inline overlays in amber and neon tones to break rigid grid boundaries.

## Layout & Spacing

The structural layout adheres to an architectural grid system engineered for dense visual merchandising and rapid vertical browsing:

- **Grid Architecture:** Desktop displays run on a 12-column layout with 20px gutters and a locked 1320px maximum container width. Mobile viewport shifts to a compact 4-column flow with 12px gutters and 16px safe margins to optimize 2-column product tile density.
- **Product Card Rhythms:** Product catalogs adopt a strict 4-column desktop and 2-column mobile matrix, maintaining uninterrupted visual cadence between apparel mockups.
- **Ticker & Trust Bands:** Ultra-dense, continuous marquee runners (`28px` to `36px` total height) sit above the header and below hero sections, delivering continuous reassurance on free pan-India logistics, COD availability, and fabric specs.

## Elevation & Depth

Visual hierarchy abandons traditional fuzzy dropshadows in favor of **Crisp Obsidian Depth & Neon Back-Glows**:

- **Layer 0 (Canvas):** `#0D0D11` baseline background.
- **Layer 1 (Card Tiers):** `#16161D` elevated tile background with a 1px razor perimeter border (`#262633`).
- **Layer 2 (Floating Trays & Modals):** `#1E1E28` surface backed by a subtle, ambient 24px blur overlay (`rgba(13, 13, 17, 0.85)`).
- **Interactive State Elevation:** Instead of physical drop shadows, buttons and elevated active cards deploy a 1px colored keyline glow (`rgba(255, 179, 0, 0.4)` or `rgba(255, 87, 34, 0.5)`) and micro-shifts of 2px on the Y-axis.

## Shapes

The geometric silhouette emphasizes disciplined, architectural streetwear sharpness:

- **Border Radii:** Base components (product cards, input fields, and standard buttons) adhere to `rounded-sm` (4px / 0.25rem), projecting an assertive, industrial edge.
- **Badges & Pills:** Filter chips, cart counter nodes, and discount highlights retain full-pill caps to evoke archival garment size tags and sticker labels.
- **Media Ratios:** Graphic tee showcases adhere strictly to a 4:5 vertical proportion to replicate editorial fashion lookbooks.

## Components

### Buttons
- **Primary Action (Instant Checkout / Buy Now):** High-voltage Electric Orange (`#FF5722`) background, crisp black text (`#0D0D11`), `Space Grotesk` Bold 14px, uppercase. Micro-hover triggers a clean amber outline offset.
- **Secondary (Add to Bag / Collections):** Dark obsidian surface (`#16161D`) framed with a 1px solid border (`#FFB300`), text colored in pure white.
- **Quick-Add Floating Action:** Compact square (`36px × 36px`) card-pinned button in deep black with an amber shopping cart icon and micro-stroke.

### Product Card
- **Structure:** Dark surface `#16161D` with 1px border `#262633`. Includes image container (4:5 ratio) with apparel artwork, wishlist heart trigger on top right, category tag, and serif garment title.
- **Pricing Cluster:** Displays final discounted price (`₹599`) alongside a strikethrough MRP (`₹1,299`) and an Electric Lime pill tag (`-54% OFF`).
- **Micro Trust Pill:** Pinned bottom bar inside cards for "240 GSM | Pure Cotton".

### Trust Strip & Payment Bar
- Segmented ribbon displaying icon-backed guarantees: **Pan-India Free Shipping**, **Instant UPI / COD Available**, **7-Day Hassle-Free Exchange**, and **100% Bio-Washed Combed Cotton**. 
- Rendered in `#16161D` with dividers in `#262633` and subtle amber-tinted vector line icons.

### Input Fields & Checkout Trays
- Form fields leverage `#101017` fills with `#262633` borders, shifting to active glowing amber `#FFB300` borders on focus.
- 1-Click Fast UPI Checkout trigger featuring logos of major Indian payment providers (GPay, PhonePe, Paytm).

### Meme Annotations & Stickers
- Absolute-positioned SVG graphic elements layered across banner portraits: jagged hand-drawn stars, highlighter underlines beneath key editorial serif words, and sticky-note style tags ("Research Chaos", "Ship In 24 Hrs").